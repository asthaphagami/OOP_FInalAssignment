package project;
public class MainClass extends TurtleGraphics {
    public static void main(String[] args) {
        new TurtleGraphics();
    }
}