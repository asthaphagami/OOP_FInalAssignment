package project;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

import uk.ac.leedsbeckett.oop.LBUGraphics;

public class TurtleGraphics extends LBUGraphics {
	private List<String> commandHistory = new ArrayList<>();
	private boolean unsavedChanges = false;
	private boolean isSaved = true;

	private boolean isInBounds(int dist) {
		double radians = Math.toRadians(getDirection());
		int x = getxPos();
		int y = getyPos();
		int newX = (int)(x + Math.cos(radians) * dist);
		int newY = (int)(y + Math.sin(radians) * dist);
		int width = getWidth();
		int height = getHeight();
		return newX >= 0 && newX < width && newY >= 0 && newY < height;}

	public TurtleGraphics() {
		JFrame mainframe = new JFrame();
		mainframe.setLayout(new FlowLayout());
		mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.add(this);
		mainframe.pack();
		mainframe.setVisible(true);
		about();}

	public void about() {
		super.about();
		displayMessage("Astha Phagami");
	}
	@Override
	public void processCommand(String arg0) {
		setBackground(Color.BLACK);
		String[] parts = arg0.trim().split(" ");
		String cmd = parts[0].toLowerCase();
		commandHistory.add(arg0);
		unsavedChanges = true;

		switch (cmd) {
			case "about": about(); break;
			case "move": {
				if (parts.length < 2) {
					System.out.println("Missing parameter.");
					break;}
				try {
					int dist = Integer.parseInt(parts[1]);
					if (dist < 0) System.out.println("Negative distance not allowed.");
					else if (!isInBounds(dist)) System.out.println("Error: Move out of bounds.");
					else forward(dist);
				} catch (NumberFormatException e) {
					System.err.println("Invalid parameters.");
				}break;}
			
			case "reverse": {
				if (parts.length < 2) System.out.println("Missing distance.");
				else try {
					int dist = Integer.parseInt(parts[1]);
					if (dist < 0) System.out.println("Negative distance not allowed.");
					else if (!isInBounds(-dist)) System.out.println("Error: Reverse out of bounds.");
					else forward(-dist);
				} catch (NumberFormatException e) {
					System.out.println("Invalid parameter.");
				}break;}
			
			case "left": {
				int deg = parts.length < 2 ? 90 : Integer.parseInt(parts[1]);
				left(deg);
				break;}
			
			case "right": {
				int deg = parts.length < 2 ? 90 : Integer.parseInt(parts[1]);
				right(deg);
				break;}
			
			case "penup": drawOff(); break;
			case "pendown": drawOn(); break;
			case "clear": {
				if (!unsavedChanges || JOptionPane.showConfirmDialog(null, "You have unsaved changes. Clear?", "Unsaved Changes", 
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					clear();
					unsavedChanges = false;
				}break;}
			
			case "reset": {
				if (!unsavedChanges || JOptionPane.showConfirmDialog(null, "You have unsaved changes. Reset?", "Unsaved Changes", 
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					reset();
					unsavedChanges = false;
				}break;}
			
			case "red": setPenColour(Color.RED); break;
			case "blue": setPenColour(Color.BLUE); break;
			case "yellow": setPenColour(Color.YELLOW); break;
			case "green": setPenColour(Color.GREEN); break;
			case "saveimg": saveImage(); break;
			case "loadimg": loadImage(); break;
			case "loadcmd": loadCommands(); break;
			case "savecmd": saveCommands(); break;
			case "square": drawSquare(parts); break;
			case "triangle": drawTriangle(parts); break;
			case "pen": setRGBPen(parts); break;
			case "penwidth": setPenWidth(parts); break;
			default: System.err.println("Error: Unknown command '" + cmd + " ");
		}}

	public void drawSquare(String[] parts) {
		if (parts.length < 2) {
			System.err.println("missing parameter for square");
			return;}
		int length = Integer.parseInt(parts[1]);
		Graphics2D g2d = (Graphics2D) getGraphics();
		g2d.setColor(getPenColour());
		for (int i = 0; i < 4; i++) {
			forward(length);
			right(90);
		}}
	
	public void drawTriangle(String[] parts) {
	    if (parts.length != 2) { displayMessage("Usage: triangle <side> or triangle <side1,side2,side3>"); return; }

	    String[] sides = parts[1].split(",");
	    if (sides.length == 1) { 
	        int side = Integer.parseInt(sides[0].trim());
	        for (int i = 0; i < 3; i++) { forward(side); left(120); }
	    } else if (sides.length == 3) {
	        int a = Integer.parseInt(sides[0].trim()), b = Integer.parseInt(sides[1].trim()), c = Integer.parseInt(sides[2].trim());
	        if (a + b > c && a + c > b && b + c > a) { forward(a); right(120); forward(b); right(120); forward(c); right(120); }
	        else displayMessage("Invalid triangle sides.");
	    } else displayMessage("Provide 1 or 3 side lengths.");
	}
	
	public void setRGBPen(String[] parts) {
		if (parts.length != 4) {
			System.err.println("requires 3 parameters");
			return;}
		try {
			int r = Integer.parseInt(parts[1]);
			int g = Integer.parseInt(parts[2]);
			int b = Integer.parseInt(parts[3]);
			setPenColour(new Color(r, g, b));
		} catch (NumberFormatException e) {
			System.err.println("Invalid");}}

	public void setPenWidth(String[] parts) {
	    try {
	        int num = Integer.parseInt(parts[1]);
	        if (num < 0) {
	            displayMessage("Negative Value in Parameter");
	        } else if (num >= 9999) {
	            displayMessage("Non-sensible Value in Parameter");
	        } else {
	            setStroke(num);
	            isSaved = false;}
	    } catch (NumberFormatException e) {
	        displayMessage("Invalid Pen Width");
	    }}
	
	public void saveImage() {
		try {
			File file = new File("img.png");
			ImageIO.write(getBufferedImage(), "png", file);
			unsavedChanges = false;
		} catch (IOException e) {
			System.err.println("ERROR:" + e.getMessage());
		}}
	
	public void saveCommands() {
		try (PrintWriter out = new PrintWriter("command.txt")) {
			for (String cmd : commandHistory) out.println(cmd);
			unsavedChanges = false;
		} catch (IOException e) {
			System.err.println("ERROR:" + e.getMessage());
		}}
	
	public void loadImage() {
		try {
			Image img = ImageIO.read(new File("img.png"));
			getGraphics().drawImage(img, 0, 0, null);
		} catch (IOException e) {
			System.err.println("Error:" + e.getMessage());
		}}

	 public void loadCommands() {
	        try (BufferedReader reader = new BufferedReader(new FileReader("command.txt"))) {
	            reset();
	            String command;
	            while ((command = reader.readLine()) != null) {
	                if (!command.equals("about")) {
	                    processCommand(command);
	                    break;
	                }
	            }
	            JOptionPane.showMessageDialog(null, "Commands loaded.");
	            repaint(); 
	        } catch (IOException e) {
	            JOptionPane.showMessageDialog(null, "Trouble loading the commands: " + e.getMessage());
	        }
	        
	    }}
